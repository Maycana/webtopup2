const harga = document.getElementById("total")
const total = document.getElementById("total1")
const pay = document.getElementById("pembayaran")
let wallet = document.querySelectorAll("p.wallet3")


function tp1(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 29.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 29.500";
  }
}
function tp2(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 83.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 83.500";
  }
}
function tp3(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 9.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 9.500";
  }
}
function tp4(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 14.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 14.500";
  }
}
function tp5(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 18.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 18.500";
  }
}
function tp6(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 27.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 27.500";
  }
}
function tp7(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 45.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 45.500";
  }
}
function tp8(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 65.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 65.500";
  }
}
function tp9(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 90.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 90.500";
  }
}
function tp10(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 135.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 135.500";
  }
}
function tp11(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 241.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 241.500";
  }
}
function tp12(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 480.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 480.500";
  }
}
function tp13(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 512.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 512.500";
  }
}
function tp14(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 570.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 570.500";
  }
}
function tp15(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 617.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 617.500";
  }
}
function tp16(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 665.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 665.500";
  }
}
function tp17(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 835.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 835.500";
  }
}
function tp18(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 865.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 865.500";
  }
}