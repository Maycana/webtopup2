const harga = document.getElementById("total")
const total = document.getElementById("total1")
const pay = document.getElementById("pembayaran")
let wallet = document.querySelectorAll("p.wallet3")


function tp1(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 40.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 40.000";
  }
}
function tp2(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 65.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 65.000";
  }
}
function tp3(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 90.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 90.000";
  }
}
function tp4(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 110.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 110.000";
  }
}
function tp5(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 135.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 135.000";
  }
}
function tp6(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 150.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 150.000";
  }
}
function tp7(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 180.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 180.000";
  }
}
function tp8(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 200.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 200.000";
  }
}
function tp9(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 225.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 225.000";
  }
}
function tp10(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 250.000";
  // payment nominal
  wallet[i].innerHTML = "Rp. 250.000";
  }
}