const harga = document.getElementById("total")
const total = document.getElementById("total1")
const pay = document.getElementById("pembayaran")
let wallet = document.querySelectorAll("p.wallet3")


function tp1(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 4.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 4.500";
  }
}
function tp2(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 6.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 6.500";
  }
}
function tp3(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 11.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 11.500";
  }
}
function tp4(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 20.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 20.500";
  }
}
function tp5(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 24.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 24.500";
  }
}
function tp6(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 47.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 47.500";
  }
}
function tp7(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 94.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 94.500";
  }
}
function tp8(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 142.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 142.500";
  }
}
function tp9(){
  for (let i = 0; i < wallet.length; i++) {
  pay.scrollIntoView();
  harga.style.display = "block";
  total.innerHTML = "Rp. 185.500";
  // payment nominal
  wallet[i].innerHTML = "Rp. 185.500";
  }
}